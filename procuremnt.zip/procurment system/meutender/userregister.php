
<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$profile=$username =$firstname=$lastname=$sex=$age=$phone= $password  =$email=$usertype= "";
$profile_err=$username_err=$firstname_err= $lastname_err=$sex_err=$age_err=$phone_err= $password_err  =$email_err=$usertype_err = "";
// Processing form data when form is submitted
if (isset($_POST['signup'])){
 
   	$sql="select * from users where username='$username'";
$res = mysqli_query($link, $sql);
$q=mysqli_num_rows($res);
				if($q>0){
				$username_err = "user name  already exist!";
				}
				  elseif(empty($_POST["username"])){
						$username_err = "Please enter a username.";
					} 
					
					else{
						$username=$_POST['username'];
					}
	if(empty($_POST["username"])){
						$username_err = "Please enter a username.";
					} 				
    // Validate password
    if(empty($_POST["password"])){
        $password_err = "Please enter a password.";     
    } elseif(strlen($_POST["password"])< 5){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = $_POST["password"];
    }
	if(empty($_POST["fname"])){
        $firstname_err = "Please enter your first name";     
    } elseif(strlen($_POST["fname"])<2){
        $firstname_err = "firstname is short!";
    } 
	 else{
        $firstname = $_POST["fname"];
    }
	if(empty($_POST["lname"])){
        $lastname_err = "Please enter your last name";     
    } elseif(strlen($_POST["lname"])<2){
        $lastname_err = "lastname is short!";
    } 
	 else{
        $lastname = $_POST["lname"];
    }

	if(empty($_POST["phone_no"])){
        $phone_err = "Please enter a your phone.";     
    } elseif(empty($_POST["phone_no"])){
        $phone_err = "please enter phone number";
    }elseif(strlen($_POST["phone_no"])!=10) {
		$phone_err = "Invalid phone number length please enter phone number";
	}
	//elseif($phone.position(0)!="0") {
		//$phone_err = "mobile no, should in the format of 09";
	
	else{
        $phone = $_POST["phone_no"];
    }
	if($_POST["sex"]=="-1"){
        $sex_err = "Please select a your sex.";     
    }  else{
        $sex = $_POST["sex"];
    }
	if(empty($_POST["age"])){
        $age_err = "Please enter a your age.";     
    }
	 elseif(strlen($_POST["age"])>3){
        $age_err = "Not valid age!";
    } 
else{
        $age = $_POST["age"];
    }
    
    // Validate confirm_password
  
	 
    if($_POST["usertype"]=='-1'){
        $usertype_err = "Please select a usertype.";     
    }  else{
        $usertype = $_POST["usertype"];
    }
	if(empty($_POST["email"])){
        $email_err = "please enter valid email";     
    }  else{
        $email = $_POST["email"];
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) ){
$firstname =$_POST['fname'];
$lastname=$_POST['lname'];
$sex=$_POST['sex'];
$age=$_POST['age'];
$phone=$_POST['phone_no'];   
$username=$_POST['username'];
$password=$_POST['password'];
$usertype=$_POST['usertype'];
$email=$_POST['email'];


$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"])); 


$query = "INSERT INTO users (profile,Firstname,Lastname,Age,Sex,phonenumber, email, username,password,usertype,status) 
					  VALUES('$file','$firstname','$lastname','$age','$sex','$phone','$email','$username','$password','$usertype','1')";
$result = mysqli_query($link, $query);
if($result)
{
	echo  '<a href="userregister.php"><script type="text/javascript">alert("Account created succesful!!!!");window.location=\'userregister.php\';</script></a>';
	//header("Location: userregister.php");
}
else
	echo "not execute";
}
    }
	

?>




<!DOCTYPE html>
<!--<?php

//include("login33.php");
?>-->
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"><!--
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->
 <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
  <link rel="stylesheet" href="css1/bootstrap.min.css">
   <script src="js1/jquery.min.js"></script>
      <script src="js1/bootstrap.min.js"></script>
 <link href="css/animate/animate.min.css" rel="stylesheet">
 <link href="css/ionicons/css/ionicons.min.css" rel="stylesheet">
  <script src="lib/wow/wow.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/login33.css">
<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="css/fontawesome.min.css">
  <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet"  href="bootstrap-5.0.2-dist/css/bootstrap.min.css">

  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:550px;color: #fff; }
  #section2 {padding-top:50px;height:700px;color: #fff;}
  #section3 {padding-top:50px;height:700px;color: #fff; background-color: #FFFFF0;}
  #section4 {padding-top:50px;height:500px;color: #fff; background-color:#F5FFFA}
  #section42 {padding-top:50px;height:1260px;color: #fff;background-color:#F0F8FF }
  #section1 {
  overflow-y: scroll;
}

  </style>

<script>
	function ValidateAlpha1(evt)
        {
            var keyCode = (evt.which) ? evt.which : evt.keyCode
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32 &&  keyCode != 8  &&  keyCode != 9)
				{
				alert("	please enter only  letters!!! ")
            return false;
			}}

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57)){
		 alert("please enter only  numbers!!! !")
            return false;

}
         
      }
	  </script>
	  <style>
	  h5{color:red;
	  text-align:center;
	  font-family:san-serif;}
	  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
     	  <div class="navbar-header">
      <a class="navbar-brand1" href="#">Web based procurement  System</a>
    </div>
	  	  	  	<img src="images/ww.jfif" width="85px" height="80px" style="margin-top:0px;margin-left:-440px;"alt="Mettu university">

    </div>

    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav menu">
	
           <li> <a href="administrator.php" ><span class="glyphicon glyphicon-home"></span>Home</a></li>
  <li><a href="userregister.php"  >User Registration</a></li>
      <li> <a href="blockaccount.php" target="iframe2">List of Active Account</a></li>
    <li><a href="deactivateaccount.php" target="iframe2">List of Blocked Account</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Setting <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="editprofile.php"><span class="glyphicon glyphicon-edit"></span>Edit&nbsp;profile</a></li>
              
			   	    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>    
  



  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
<div id="section1" class="container-fluid" style="visibility: visible; animation-name: fadeInUp; -webkit-animation-name: fadeInUp;">
<div class="login-wrap">
  <div class="login-html">
    <!--<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>-->
	<h5>Click here to view  Form</h5>
    <input id="tab-2" type="radio" name="tab" class="sign-up" ><label for="tab-2" class="tab">&nbsp;&nbsp;&nbsp&nbsp;User Sign Up Form</label>
    <div class="login-form">
    
	
	  
      <form class="sign-up-htm" action="userregister.php" method="POST" name="account" onsubmit="return validateForm();" enctype="multipart/form-data">
        <div class="group ">
          <label for="user" class="label">Firstname</label>
          <input id="username" name="fname" type="text" class="input" value="<?php echo $firstname; ?> "onKeyPress="return ValidateAlpha1(event)" >
                 <span class="help-block" style="color:red"><?php echo $firstname_err; ?></span>

		</div>
		<div class="group ">
          <label for="user" class="label">Last Name</label>
          <input id="lname" name="lname" type="text" class="input"value="<?php echo $lastname; ?> " onKeyPress="return ValidateAlpha1(event)" >
		 		  <span class="help-block" style="color:red"><?php echo $lastname_err; ?></span>

        </div>
		<div class="group ">
          <label for="user" class="label">Age</label>
          <input id="age" name="age" type="text" class="input" value="<?php echo $age; ?> "onKeyPress="return isNumberKey(event)" >
		 		  <span class="help-block" style="color:red"><?php echo $age_err; ?></span>

        </div>
		 <div class="group">
          <label for="sex" class="label">Sex</label>
  <select name="sex" class="input" value="<?php echo $sex; ?> "required="">
  <option value="-1">Please select  you sex</option>
  
            <option value="Male">Male</option>
  <option value="Female">Female</option>         
</select>
<span class="help-block" style="color:red"><?php echo $sex_err; ?></span>

        </div>
		<div class="group ">
          <label for="user" class="label">Phone number</label>
          <input id="phone" name="phone_no" type="text" value="<?php echo $phone; ?> "class="input" onKeyPress="return isNumberKey(event)" >
		 		 <span class="help-block" style="color:red"><?php echo $phone_err; ?></span>

        </div>
		<div class="group ">
          <label for="email" class="label">Email</label>
          <input id="email" type="email" class="input" data-type="email" value="<?php echo $email; ?> "name="email" onKeyPress="return validateForm()"   >
		  		   <span class="help-block" style="color:red"><?php echo $email_err; ?></span>

        </div>
		<div class="group ">
          <label for="profile" class="label">Profile_image</label>
		  <input style="color:green" type="file"  class="input" id="profile" name="image" id="image" /> 
 		           <span class="help-block" style="color:red"><?php echo $profile_err; ?></span>

        </div>
		<div class="group ">
          <label for="user" class="label">Username</label>
          <input id="username" name="username" type="text" class="input"value="<?php echo $username; ?> " onKeyPress="return validateForm()"  >
		 		  <span class="help-block" style="color:red"><?php echo $username_err; ?></span>

        </div>
        <div class="group ">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="text" class="input"  value="<?php echo $password; ?>" onchange="return FormValidationall();" onKeyPress="return validateForm()">
		   <span class="help-block" style="color:red"><?php echo $password_err; ?></span>
        </div>
      <!--
        <div class="group">
          <label for="pass" class="label">Confirm_Password</label>
          <input id="pass" type="text" class="input"  name="confirm_password" value="<?php echo $confirm_password; ?>" onchange="return FormValidationall();" onKeyPress="return validateForm()" >
		   <span class="help-block" style="color:red"><?php echo $confirm_password_err; ?></span>
        </div>-->
         <div class="group">
          <label for="username" class="label">User Type</label>
  <select name="usertype" class="input" value="<?php echo $usertype; ?> "required="">
  <option value="-1">Please select user type</option>
  
            <option value="Administrator">Administrator</option>
  <option value="Procurement_Team">Procurement team</option>

      <option value="property_Department">Property Department</option>
        <option value="procurement_Approving_committee">Procurement Approving committee</option>
          <option value="Finance">Finance</option>
          
              <option value="scientific_director">Scientific Director</option>
              
</select>
<span class="help-block" style="color:red"><?php echo $usertype_err; ?></span>

        </div>
        
        <div class="group">
           <button type="btn btn-sucess"type="submit" class="button" name="signup">Create account</button>
		    <button type="reset" class="button" name="reset">Clear Form</button>
        </div>
        <div class="hr"></div>
      </form>
    </div>
  </div>
</div>

</div>



<footer id="footer">
   

    <div class="container">
      <div class="copyright">
        © Copyright <strong>jimma University procurement system | 2022</strong>. All Rights Reserved
      </div>
      <div class="credits"> 
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
     <!-- Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade--> 
      </div>
   
                        </div>
  </footer>
   
	 
</body>

</html>
