<?php
$a=mysqli_connect("localhost","root","");
if(!$a){die('not connet'.mysqli_error($a));}
$d=mysqli_select_db($a,"tender");
if(!$d){die('not select'.mysqli_error($a));}
if(isset($_GET['id'])){
		$id = $_GET['id'];
$query="DELETE FROM request WHERE checked='yes' AND id='$id'";
$res=mysqli_query($a,$query);
if(!$res)
{
echo '<script type="text/javascript">alert("please wait not seen!!?");window.location=\'approvedrequest.php\';</script>'.mysqli_error($a);
}
else
echo '<script type="text/javascript">confirm("Are you sure to delete?");window.location=\'approvedrequest.php\';</script>';
}
?>