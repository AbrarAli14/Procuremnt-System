CREATE TABLE IF NOT EXISTS `users`(
`user_id` int(100) NOT NULL AUTO_INCREMENT,
`profile` blob not null,
`firstname` varchar(20) not null,
`lastname` varchar(20) not null,
`Age` int not null,
`Sex` varchar(20) not null,
`phonenumber` varchar(20) not null,
`email` varchar(20) not null,
`username` varchar(20) not null,
`password` varchar(20)not null,
`confirmpassword` varchar(20) not null,
`usertype` varchar(20) not null,
`status` int,
primary key(user_id)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(1,'adamu','alemu',23,'male','0943247181','adamu2@gmail.com','adamu123','234432','234432','procurement_team',1);
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(2,'beshir','adem',22,'male','0934343434','beshir@gmail.com','beshir123','890098','890098','property_department',1);
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(3,'seada','kassaw',20,'female','0933455454','seada2@gmail.com','seada123','678876','678876','finance',1);
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(4,'Getaneh','Geto',20,'male','0945691034','getaneh@gmail.com','gech123','123321','123321','Administrator',1);
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(5,'ayele','ababu',23,'male','0933455454','ayele@gmail.com','ayele123','456654','456654','scientific_director',1);
insert into `users`(`user_id`,`firstname`,`lastname`,`Age`,`Sex`,`phonenumber`,`email`,`username`,`password`,`confirmpassword`,`usertype`,`status`)
values(6,'abebe','mamo',20,'male','0933455454','abebe@gmail.com','abebe123','123456','123456','procurement_approving_committee',1);


CREATE TABLE IF NOT EXISTS `request`(
`rid` int(100) not null AUTO_INCREMENT,
`name` varchar(20) not null,
`date` date not null,
`reason` varchar(300) not null,
`itemkind` varchar(30) not null,
`itemmodel` varchar(20) not null,
`measure` varchar(20) not null,
`quantity` int not null,
`unitprice` int not null,
`totalprice` int not null,
`status` varchar(30) not null,
`approve` varchar(20) not null,
`checked` varchar(20),
primary key(rid)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `feedback`(
`fid` int(100) not null AUTO_INCREMENT,
`itemname` varchar(20),
`itemmodel`varchar(20),
`firstname` varchar(20),
`lastname` varchar(20),
`email` varchar(20) not null,
`date` date not null,
`message` varchar(20),
`status` int(100),
primary key(fid)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;
CREATE TABLE IF NOT EXISTS `feedbackfin`(
`fid` int(100) not null AUTO_INCREMENT,
`itemname` varchar(20),
`itemmodel`varchar(20),
`firstname` varchar(20),
`lastname` varchar(20),
`email` varchar(20) not null,
`date` date not null,
`message` varchar(20),
`status` int(100),
primary key(fid)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `feedbackpr`(
`fid` int(100) not null AUTO_INCREMENT,
`firstname` varchar(20),
`lastname` varchar(20),
`email` varchar(20) not null,
`date` date not null,
`message` varchar(20),
`status` int(100),
primary key(fid)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `biddocument`(
`no` int(100) not null AUTO_INCREMENT,
`date` date,
`item_name` varchar(20),
`item_model` varchar(20) not null,
`market_birr` int,
`supplier_birr` int,
`open_date` date not null,
`close_date` date not null,
`instruction` varchar(20),
`status` varchar(20),
primary key(no)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `registerdsupplier`(
`campany_name` varchar(30) not null,
`tin_no` int(100) not null,
`city` varchar(20) not null,
`email` varchar(20) not null,
`telephone` int(100) not null,
`fax_no` varchar(20) not null,
`no` int(100) not null,
`prepare_date` date,
`item_name` varchar(20),
`item_model` varchar(20) not null,
`market_birr` int,
`supplier_birr` int,
`open_date` date not null,
`close_date` date not null,
`fill_date` date not null,
`status` varchar(20) not null

)ENGINE=InnoDB  DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `assessdsupplier`(
`id` int(100) not null,
`campany_name` varchar(30) not null,
`tin_no` int(100) not null,
`city` varchar(20) not null,
`email` varchar(20) not null,
`telephone` int(100) not null,
`fax_no` varchar(20) not null,
`no` int(100) not null,
`prepare_date` date,
`item_name` varchar(20),
`item_model` varchar(20) not null,
`market_birr` int,
`supplier_birr` int,
`open_date` date not null,
`close_date` date not null,
`assess_date` date not null,
` wutet` varchar(200) not null,
`reason` varchar(2000) not null,
`status`  varchar(20) not null

)ENGINE=InnoDB  DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `news`(
`nid` int(100) not null,
`notice` varchar(20),
`status` int(10)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `items`(
`no` int(100) not null,
`register_date` date,
`item_name` varchar(20),
`item_model` varchar(20) not null
)ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;
create table IF NOT EXISTS `contact`(
name varchar(20) not null,
email varchar(200) not null,
subject varchar(200)
message varchar(500) not null


))ENGINE=InnoDB  DEFAULT CHARSET=latin1;