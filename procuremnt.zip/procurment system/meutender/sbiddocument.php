﻿<?php
$mysql = mysqli_connect("localhost","root","");
mysqli_select_db($mysql,"tender");
 session_start();
if(isset($_SESSION['user_id']))
 {
	
  $mail=$_SESSION['user_id'];
   $n=$_SESSION['username'];
 } else {

 ?>
<script>
  alert('You are not logged In !! Please Login to access this page');
  alert(window.location='index.php');
 </script>
 <?php
 }
 ?>
 			<?php 

$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"tender");
$result = mysqli_query($con,"SELECT * FROM request where status='pending...' "); 
//$num_rows = mysqli_num_rows($result); 
$count1=($result? mysqli_affected_rows($con):0);


?>
<?php 

$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"tender");
$result = mysqli_query($con,"SELECT * FROM feedback where status='pending...' "); 
$count=($result? mysqli_affected_rows($con):0);


?>
<!DOCTYPE html>
<html>
<head>
  <title>procurement system For JU</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"><!--
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->
 <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
  <link rel="stylesheet" href="css1/bootstrap.min.css">
   <script src="js1/jquery.min.js"></script>
      <script src="js1/bootstrap.min.js"></script>
 <link href="css/animate/animate.min.css" rel="stylesheet">
 <link href="css/ionicons/css/ionicons.min.css" rel="stylesheet">
  <script src="lib/wow/wow.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/login33.css">
<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="css/fontawesome.min.css">
  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:570px;color: #fff; }
  
 
.prof{
border-radius:50px;
height:700px;
}
.img-thumnail{border-radius:450px;}
.use{font-size:18px;}
table{
	color:black;
}
th{
	height:100px;
	background-color:#999999;
	font-size:20px;
	
}
td{
	font-size:17px;
	height:90px;
	font-size:16px;
	
}
.request_form{
	color:black;
}
  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
     
	  	<img src="images/ww.jfif" width="90px" height="80px" style="margin-top:0px;margin-left:-540px;"alt="Mettu university">

    </div>
		  <div class="navbar-header">
      <a class="navbar-brand1" href="#">Web based procurement System</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav menu">
	
           <li> <a href="supplier.php" ><span class="glyphicon glyphicon-home"></span>Home</a></li>
		    
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">View <span class="caret"></span></a>
            <ul class="dropdown-menu">
			  <!--<li><a href="approved_procurement.php" target="iframe2">Approve procurement</a></li>-->
          
    <li> <a href="sbiddocument.php"  target="iframe2">Bid_Document</a></li>

      <li><a href="supplierwins.php"  target="iframe2">Winner supplier</a></li>
	  <li> <a href="supplierfails.php"  target="iframe2">supplier Fail</a></li>
		
            </ul>
          </li>
	
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Setting <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="editprofileps.php"><span class="glyphicon glyphicon-edit"></span>Edit&nbsp;profile</a></li>
            
			   	    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>    
  

<div id="section1" class="container-fluid" style="visibility: visible; animation-name: fadeInUp; -webkit-animation-name: fadeInUp;">
<center>
<div class="request_form">
<form name="request" action="biddocument.php" method="POST">
<fieldset>
    <legend>jimma University Tender Bid Document Form</legend>
  <fieldset>
    <legend>Suppliers  Procedure</legend>
	
   
   <label>Procedure</label>
   <textarea type="text" class="textarea" name="procedure" rows="100" cols="30" required>
	 1.Suppliers only fill the birr in the bid document prepared by the procurement team .
	 2.Any bids document is forbidden after tender closed.
	 3.Winner supplier must be  made contract with the university.
	 4.Winner suppliers  must come the items by your own transport to  the university.
	 </textarea><br><br></fieldset>
<fieldset>
<legend>Item Discription</legend>
 <table border="1" width="1000" align="center" cellpadding="3" class="mytable" cellspacing="0">
                <tr>
<th>No </th>
<th>Date</th> <th> Item_Name</th><th>Discription</th>
<th> market_birr</th><th>supplier_birr</th><th> open_date </th>
<th> close_date </th><th> status </th>
<th colspan="2">View</th>
            </tr>
			  <?php
			  	
			  $result = mysqli_query($mysql," SELECT * FROM biddocument ");
			  if($result === false){
    echo "the error is".mysqli_error($mysql);
}
while($row = mysqli_fetch_array($result)){
	
		$no=$row['no'];$date=$row['date'];$cdate=$row['close_date'];$odate=$row['open_date'];
		$pro=$row['instruction'];
		$itemname=$row['item_name'];
		if(isset($row['Discription'])){
		$itemmodel=$row['Discription'];}
		$mbirr=$row['market_birr'];
		$supbirr=$row['supplier_birr'];
		$status=$row['status'];
		?>
		       
		<tr>	
<td><?php echo $no ;?></td><td><?php echo $date; ?></td> 
<td><?php echo $itemname; ?></td><td><?php 
if(isset($row['itemmodel'])){echo $itemmodel;} ?></td>
<td><?php echo $mbirr;  ?></td><td><?php echo $supbirr;?></td>
<td><?php echo $odate; ?></td><td><?php echo $cdate;?></td>
<td style="color:red;"><?php echo $status;?></td>
<td><button type="button" class="btn btn-info active btn-sm" data-toggle="modal" data-target="#myModal">register</button></td>
<!--<td><a href="supsearch.php?id=<?php echo $row['no'] ?>"><button type="button" name="btn" class="btn btn-sucess" > register </button></a></td>--->
</tr>

<?php
  }	
  $sql="SELECT * FROM  biddocument";
  $result=mysqli_query($mysql,$sql);
	$records = mysqli_num_rows($result);
	if(!$records){
	echo "the error is".mysqli_error($mysql);}
    ?>
	 <tr>
              <td align="center" colspan="15" ><?php echo "Total ".$records." biddocument prepared"; ?> </td>
            </tr>
			<?php

?></table></fieldset>
</fieldset>

</form></div></center>

</div>

<footer id="footer">
   

    <div class="container">
      <div class="copyright">
        © Copyright <strong>jimma University procurement system | 2022</strong>. All Rights Reserved
      </div>
      <div class="credits"> 
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
     <!-- Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade--> 
      </div>
   
                        </div>
  </footer>
  

 <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><center><h4>I.If you want  register please pay bid document price and search the by no.</h2></center></h4>
      </div>
      <div class="modal-body">
<form  method="POST" action="sregister.php">
<i></i>
<div class="form-group">
<label class="control-label col-sm-2" for="no"><i>No:</i></label>
<div class="col-sm-10">
<input class="form-control" type="text" name="id" required/></div>
<label class="control-label col-sm-2" for="no"><i>Price:</i></label>
<div class="col-sm-10">
<input placeholder="enter 100 birr for bid security" type="text"  required/></div>
  </div>
<br><br><br><br><br><br><br><br></div>
<div class="modal-footer">
<button style=" float:right;"   class="btn btn-success active" type="submit" name="update" >Search</button>
        <button type="button" class="btn btn-danger active" data-dismiss="modal">Close</button>
      </div>
</form>
 
</div></div></div>
</body>

</html>
