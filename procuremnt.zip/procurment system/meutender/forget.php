
<!DOCTYPE html>
<?php

include("login33.php");
?>
<html>
<head>
<title>Procurment System For MEU</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!--
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> --> 
  
  <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
  <link rel="stylesheet" href="css1/bootstrap.min.css">
   <script src="js1/jquery.min.js"></script>
      <script src="js1/bootstrap.min.js"></script>
<link href="css/animate/animate.min.css" rel="stylesheet">
 
  <link rel="stylesheet" type="text/css" href="css/login33.css">
<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="css/fontawesome.min.css">
  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:580px;color: #fff; }

.textt{
	
	margin-top:100px;
}
.text{
	float:left;
	width:400px;
	
}
  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand1" href="#">Web Based Procurment System</a>
	  	<img src="images/ww.jfif" width="100px" height="90px" style="margin-top:0px;margin-left:-540px;"alt="Mettu university">

    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav menu">
          <li class="current-menu-item"><a href="index.php" target="iframe3">Home</a></li>
             
         
        </ul>
      </div>
    </div>
  </div>
</nav>    
<div id="section1" class="container-fluid">
<div class="text" style="margin-top:50px;float:left;margin-left:-500px;">
<h4> Do you forget key?</h4>
<img src="images/uu.gif" width="200px" height="200px">
</div>
  <div class="textt">
<?php

 if(isset($_POST['view']))
  {
   $username=$_POST['username'];
   $phone=$_POST['phone'];
   $lname=$_POST['lname'];
   $sql="SELECT * FROM users where username='$username' AND phonenumber='$phone' AND lastname='$lname';"; 
   $result_set=mysqli_query($link,$sql);
   if(!$result_set)
   {
   die("Query failed".mysqli_error($link));
   }
if(mysqli_num_rows($result_set)>0)
{
while($row=mysqli_fetch_array($result_set))
{
$fname=$row[2];
$password=$row['password'];

echo"<font color='red' size='12px' style='text-decoration:blink'><p class='success'>"."Hi"."&nbsp; &nbsp;".$fname."&nbsp; &nbsp;"."your password is:".$password."</font></p>";
echo'<meta content="6;index.php" http-equiv="refresh" />';

}}
else
{
echo"<p class='wrong'>Incorrect Input</p>";
echo'<meta content="10;forget.php" http-equiv="refresh" />';
}
}
mysqli_close($link);
?>

<form action="forget.php" method="POST">
           <table class="log_table" align="center" >

<tr bgcolor="#51a351" ><th colspan="2" ><font color="#ffffff">Do you forget password?</font></th></tr>
<tr><td>
<label>Last Name</label>
</td>
<td>
<input type="text" name="lname" required x-moz-errormessage="Enter last name!" onkeypress="ValidateAlphaf(evt)"/></td></tr>
<tr>
<td>
<label>phone number</label></td>
<td>
<input type="text" name="phone" required x-moz-errormessage="Enter phone number!" onkeypress="isNumberKeya(evt)"/></td></tr>
<tr>
<td>
<label>User Name</label>
</td>
<td>
<input type="text" name="username" required x-moz-errormessage="Enter Username!"/>
</td>
</tr>
<tr><td>
</td><td>
<button type="submit" name="view"  class="btn btn-success">Recover</button>
<button type="reset" class="btn btn-warning">Reset</button>
</td>
</tr>
<tr><td>
</td><td>
<br></td></tr>
</form>
</table>
</div>
</div>

<footer id="footer">
   

    <div class="container">
      <div class="copyright">
        © Copyright <strong>Jimma University Procurment system | 2022</strong>. All Rights Reserved
      </div>
      <div class="credits"> 
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
     <!-- Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade--> 
      </div>
   
                        </div>
  </footer>
 
</body>

</html>
