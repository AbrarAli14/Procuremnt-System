
<!DOCTYPE html>
<?php

include("login33.php");
?>
<html>
<head>
  <title>procurment system For JU</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"><!--
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>--->
  <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
  <link rel="stylesheet" href="css1/bootstrap.min.css">
   <script src="js1/jquery.min.js"></script>
      <script src="js1/bootstrap.min.js"></script>
<link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
 <link href="css/animate/animate.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/login33.css">
<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="css/fontawesome.min.css">
  <link href="css/style.css" rel="stylesheet">
  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:900px;color: #fff;}
  #section2 {padding-top:50px;height:700px;color: #fff;}
  #section3 {padding-top:50px;height:700px;color: #fff; background-color: #FFFFF0;}
  #section4 {padding-top:50px;height:500px;color: #fff; background-color:#F5FFFA}
  #section42 {padding-top:50px;height:1260px;color: #fff; }
 

  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      
	  
	  	<img src="images/ww.jfif" width="100px" height="90px" style="margin-top:-5px;margin-left:-540px;"alt="jimma university">

    </div>
	  <div class="navbar-header">
      <a class="navbar-brand1" href="#">Web based Procurment System</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav menu">
          <li class="current-menu-item"><a href="index.php" target="iframe3"><span class="glyphicon glyphicon-home"></span>Home</a></li>
           
			</li>
			<li><a href="#section1" ><span class="glyphicon glyphicon-quationmark"></span>News</a></li>
			
	
            </li>
             
          
        </ul>
      </div>
    </div>
  </div>
</nav>    
<div id="section1" class="container-fluid" style="visibility: visible; animation-name: fadeInUp; -webkit-animation-name: fadeInUp;">
<center>
  <div class="notice" style="color:black;font-family:san serif;font-size:20px;">

          <p> Notice</p>
 <hr>
			  <?php 
$mysql=mysqli_connect('localhost','root','');
		$db_selected=mysqli_select_db($mysql,"tender") or die("couldnot select database");
			  $query = mysqli_query($mysql," SELECT * FROM news ORDER BY nid DESC 
                        LIMIT 1");
		
			 if(!empty($query)){
				 
				  while($row=mysqli_fetch_array($query)){
			 $new=$row['message'];
			 echo $new;
			 
			 }}
			 else{
				 
				
			echo"<script>alert('no posted news!');</script>".mysqli_error($mysql);
			 
			 }
			
			 
			
			?>	  




</div></center>
</div>
<div id="section41" class="container-fluid">

</div>
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            

            <div id="social"> 
           </a><p><a href="http://Mettu.university/"> </a><a class="facebookBtn smGlobalBtn" style="height:5px, width:5px" href="https://www.facebook.com/JimmaUniversity111/?ref=br_rs" target="_blank"></a>
			<a class="twitterBtn smGlobalBtn" href="https://twitter.com/Mettuuniversity" target="_blank"></a>
			<a class="googleplusBtn smGlobalBtn"></a>
		<a class="youtubeBtn smGlobalBtn" href="https://www.youtube.com/channel/UCDPKF_tmJ1cz3JFxVfCU2Ig" target="_parent"></a>
		</p>
		</div>

          </div>

          

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        © Copyright <strong>jimma  University procurment system | 2022</strong>. All Rights Reserved
      </div>
      <div class="credits"> 
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
     <!-- Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade--> 
      </div>
    </div><div style="width: 100%;">  <a href="developer.php" style="color: red "><b> Developer</b></a>
                        </div>
  </footer>
     
</body>

</html>
