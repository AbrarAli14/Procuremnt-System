
<!DOCTYPE html>
<?php

include("login33.php");
?>
<html>
<head>
  <title>Procurment System For JU</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"><!---
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->
   <script src="js1/jquery.min.js"></script>
  <link rel="stylesheet" href="css1/bootstrap.min.css">
   <link rel="stylesheet" href="css/fontawesome.min.css">
<link rel="stylesheet" type="text/css" href="css1/animate/animate.css">
   <script src="js1/bootstrap.min.js"></script> 
  <link rel="stylesheet" type="text/css" href="css/login33.css">
<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
  <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/developer.css">
  <link href="css/style.css" rel="stylesheet">
  <!-- Libraries CSS Files -->
  <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="css1/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  
  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:900px;color: #fff; background-color: black;}
  #section2 {padding-top:50px;height:700px;color: #fff;}
  #section3 {padding-top:50px;height:700px;color: #fff; background-color: #FFFFF0;}
  #section4 {padding-top:50px;height:1000px;color: #fff; background-color:#F5FFFA}
  #section42 {padding-top:50px;height:1260px;color: #fff;background-color:#F0F8FF }
  
  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
    
	
		  	<img src="images/w.jpg" width="100px" height="90px" style="margin-top:-95px;margin-left:-28px;"alt="Mettu university">

    </div>
	
	<div class="navbar-header">
      <a class="navbar-brand1" href="#">Web based Procurment System</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav menu">
          <li class="current-menu-item"><a href="index.php" ><span class="glyphicon glyphicon-home"></span>Home</a></li>
         
		
		
           
         
          
        </ul>
      </div>
    </div>
  </div>
</nav>    



<main role="main">          
 <section class="subpage content">
        
            <div class="container clearfix">
                <div class="row">
            
                        
                
           
<!------ Include the above in your HEAD tag ---------->

<!-- Team -->
<section id="team" class="pb-5" class="wow fadeInUp">
    <div class="container">
        <h5 class="section-title">Jimma University Web based Procurment System Developers Team Profile </h5>
        <div class="row">
            
              <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/bro.jpg" width="500" height="600"alt="card image"></p>
                                    <h4 class="card-title">Binyam denekew</h4>
                                    <p class="card-text">Student at Jimma University Department of Information Technology<br>
                                  </p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Biniyam denekew</h4>
                                    <p class="card-text">social links
                                 <div class="social">
                    <a href="www.twitter.com"><i class="fa fa-twitter"></i></a>
                    <a href="www.facebook.com"><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-google-plus"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                  </div>
                                                
                                </p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</section>
<!-- Team -->               
             </div>            
        </div></section>

</main>
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            

         <div id="social"> 
           </a><p><a href="http://Mettu.university/"> </a><a class="facebookBtn smGlobalBtn" style="height:5px, width:5px" href="https://www.facebook.com/MettuUniversity111/?ref=br_rs" target="_blank"></a>
			<a class="twitterBtn smGlobalBtn" href="https://twitter.com/Mettuuniversity" target="_blank"></a>
			<a class="googleplusBtn smGlobalBtn"></a>
		<a class="youtubeBtn smGlobalBtn" href="https://www.youtube.com/channel/UCDPKF_tmJ1cz3JFxVfCU2Ig" target="_parent"></a>
		</p>
		</div>

          </div>

          

        </div>
      </div>
    </div>

    <div class="container">
	
      <div class="copyright">
        © Copyright <strong>Jimma University Procurment system | 2022</strong>. All Rights Reserved
      </div>
      <div class="credits"> 
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
     <!-- Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade--> 
      </div>
    </div><div style="width: 100%;">  <a href="developer.php" style="color: red "><b> Developer</b></a>
                        </div>
  </footer>
</body>

</html>
